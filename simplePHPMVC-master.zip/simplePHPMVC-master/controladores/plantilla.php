<?php

if ($method == "get"){
   
}
if ($method == "post"){
    
}
?>