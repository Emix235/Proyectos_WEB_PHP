# taller_practico_js
videogame made with html, css and javascript.
